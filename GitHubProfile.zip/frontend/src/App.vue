<script setup>
import { ref } from 'vue'
import GitHubProfile from './components/GitHubProfile.vue'
import Notification from './components/Notification.vue'

const username = ref('')
const notifications = ref([])

// helper to push notifications
function pushNotification({ type = 'info', message = '', timeout = 3500 }) {
  const id = Date.now() + Math.random()
  notifications.value.push({ id, type, message, timeout })
}

// handle profile events
function onProfileLoaded(profile) {
  pushNotification({ type: 'success', message: `Profile ${profile.login} loaded` })
}

function onProfileError(err) {
  pushNotification({ type: 'error', message: `Error: ${err}` })
}

// remove notification by id
function removeNotification(id) {
  notifications.value = notifications.value.filter(n => n.id !== id)
}
</script>

<template>
  <div style="max-width:900px;margin:24px auto;padding:12px;">
    <h1>Практика: GitHub профиль + уведомления</h1>

    <div style="display:flex;gap:8px;margin-bottom:12px;">
      <input
        v-model="username"
        @keyup.enter="$refs.profile?.fetchProfile(username)"
        placeholder="Введите github username и нажмите Enter"
        style="flex:1;padding:8px;border-radius:6px;border:1px solid #ddd;"
      />
      <button @click="$refs.profile?.fetchProfile(username)">Search</button>
    </div>

    <div style="display:flex;gap:16px;">
      <div style="flex:1;">
        <GitHubProfile
          ref="profile"
          :username="username"
          @loaded="onProfileLoaded"
          @error="onProfileError"
        />
      </div>

      <div style="width:320px;">
        <h3>Notifications</h3>
        <div>
          <Notification
            v-for="note in notifications"
            :key="note.id"
            :type="note.type"
            :timeout="note.timeout"
            @dismiss="removeNotification(note.id)"
          >
            {{ note.message }}
          </Notification>

          <div v-if="!notifications.length" style="color:#666">Нет уведомлений</div>
        </div>
      </div>
    </div>
  </div>
</template>
