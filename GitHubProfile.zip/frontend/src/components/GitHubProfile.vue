<script setup>
import { ref, watch, onMounted } from 'vue'


const props = defineProps({
  username: {
    type: String,
    required: true
  },
  autoFetch: {
    type: Boolean,
    default: true
  }
})

const emit = defineEmits(['loaded', 'error'])

const loading = ref(false)
const error = ref(null)
const profile = ref(null)

async function fetchProfile(name) {
  if (!name || !name.trim()) {
    profile.value = null
    error.value = 'Empty username'
    emit('error', error.value)
    return
  }

  loading.value = true
  error.value = null
  profile.value = null

  try {
    const res = await fetch(`https://api.github.com/users/${encodeURIComponent(name)}`)
    if (!res.ok) {
      if (res.status === 404) throw new Error('User not found')
      throw new Error(`GitHub API error: ${res.status}`)
    }
    const data = await res.json()
    profile.value = {
      login: data.login,
      name: data.name,
      bio: data.bio,
      avatar: data.avatar_url,
      html_url: data.html_url,
      followers: data.followers,
      following: data.following,
      repos: data.public_repos,
      location: data.location,
    }
    emit('loaded', profile.value)
  } catch (err) {
    error.value = err.message || String(err)
    emit('error', error.value)
  } finally {
    loading.value = false
  }
}

watch(() => props.username, (nv, ov) => {
  if (nv && nv.trim()) fetchProfile(nv)
  else {
    profile.value = null
    error.value = null
  }
}, { immediate: props.autoFetch })

defineExpose({
  fetchProfile
})
</script>

<template>
  <section class="gh-profile" aria-live="polite">
    <div v-if="loading" class="loading">Loading profile…</div>

    <div v-else-if="error" class="error">
      <strong>Error:</strong> {{ error }}
    </div>

    <div v-else-if="profile" class="profile">
      <img :src="profile.avatar" alt="avatar" class="avatar" />
      <div class="info">
        <h2><a :href="profile.html_url" target="_blank" rel="noopener">{{ profile.name || profile.login }}</a></h2>
        <p class="login">@{{ profile.login }}</p>
        <p class="bio" v-if="profile.bio">{{ profile.bio }}</p>
        <p class="meta">
          <span>{{ profile.repos }} repos</span>
          <span>•</span>
          <span>{{ profile.followers }} followers</span>
          <span>•</span>
          <span>{{ profile.following }} following</span>
        </p>
        <p v-if="profile.location" class="location">📍 {{ profile.location }}</p>
      </div>
    </div>

    <div v-else class="empty">Введите GitHub username и нажмите Enter или кнопку поиска.</div>
  </section>
</template>

<style scoped>
.gh-profile { border: 1px solid #e6e6e6; padding: 12px; border-radius: 8px; background: #fff; }
.loading { color: #1976d2; }
.error { color: #c62828; }
.profile { display:flex; gap: 12px; align-items: center; }
.avatar { width:72px; height:72px; border-radius: 8px; object-fit:cover; }
.info h2 { margin: 0; font-size: 1.1rem; }
.login { color: #666; margin: 4px 0; }
.meta { color: #444; font-size: 0.9rem; margin-top: 6px; }
.empty { color: #666; }
</style>
