
<script setup>
import { ref, watch } from 'vue'

const LS_KEY = 'vue_todo_list_v1'

const items = ref(
  JSON.parse(localStorage.getItem(LS_KEY) || 'null') || [
    { id: 1, text: 'Купить продукты', done: false },
    { id: 2, text: 'Позвонить маме',    done: false },
    { id: 3, text: 'Пройти урок по Vue', done: false },
  ]
)

const newText = ref('')

watch(items, (v) => {
  localStorage.setItem(LS_KEY, JSON.stringify(v))
}, { deep: true })

function toggleDone(item) {
  item.done = !item.done
}

function addItem() {
  const t = newText.value.trim()
  if (!t) return
  const nextId = items.value.length ? Math.max(...items.value.map(i => i.id)) + 1 : 1
  items.value.push({ id: nextId, text: t, done: false })
  newText.value = ''
}

function removeItem(id) {
  items.value = items.value.filter(i => i.id !== id)
}
</script>

<template>
  <main class="todo-page">
    <h1>Список дел</h1>

    <div class="add-row">
      <input
        v-model="newText"
        @keyup.enter="addItem"
        placeholder="Добавить задачу и нажать Enter"
        aria-label="Новая задача"
      />
      <button @click="addItem" :disabled="!newText.trim()">Add</button>
    </div>

    <ul class="todo-list" role="list">
      <li
        v-for="item in items"
        :key="item.id"
        class="todo-item"
      >
        <div
          class="todo-body"
          :class="{ done: item.done }"
          role="button"
          tabindex="0"
          @click="toggleDone(item)"
          @keyup.enter.prevent="toggleDone(item)"
          @keyup.space.prevent="toggleDone(item)"
          :aria-pressed="String(item.done)"
        >
          <span class="checkmark" aria-hidden="true">
            <svg v-if="item.done" width="16" height="16" viewBox="0 0 24 24"><path fill="currentColor" d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/></svg>
          </span>
          <span class="text">{{ item.text }}</span>
        </div>

        <button class="remove" @click="removeItem(item.id)" aria-label="Удалить задачу">&times;</button>
      </li>

      <li v-if="!items.length" class="empty">Список пуст — добавьте задачу</li>
    </ul>
  </main>
</template>

<style scoped>
.todo-page {
  max-width: 640px;
  margin: 32px auto;
  padding: 16px;
  font-family: Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
  color: #111;
}

h1 {
  text-align: center;
  margin-bottom: 16px;
}

.add-row {
  display: flex;
  gap: 8px;
  margin-bottom: 16px;
}
.add-row input {
  flex: 1;
  padding: 8px 10px;
  border-radius: 8px;
  border: 1px solid #ddd;
  outline: none;
}
.add-row input:focus { box-shadow: 0 0 0 3px rgba(100,150,255,0.12); }
.add-row button {
  padding: 8px 12px;
  border-radius: 8px;
  border: none;
  cursor: pointer;
  background: #1976d2;
  color: white;
}
.add-row button:disabled { opacity: 0.5; cursor: default; }

.todo-list {
  list-style: none;
  padding: 0;
  margin: 0;
}
.todo-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px;
  margin-bottom: 8px;
  border-radius: 10px;
  background: #fafafa;
  border: 1px solid rgba(0,0,0,0.04);
}

.todo-body {
  display: flex;
  align-items: center;
  gap: 10px;
  cursor: pointer;
  user-select: none;
  flex: 1;
  outline: none;
}
.todo-body:focus { box-shadow: 0 0 0 3px rgba(25,118,210,0.12); border-radius: 6px; }

.todo-body.done .text {
  text-decoration: line-through;
  opacity: 0.6;
  transition: all 0.15s ease;
}

.checkmark {
  width: 20px;
  height: 20px;
  display: inline-grid;
  place-items: center;
  border-radius: 50%;
  background: rgba(25,118,210,0.08);
}
.todo-body.done .checkmark { background: rgba(25,118,210,0.18); color: #0b63d6; }

.remove {
  margin-left: 12px;
  border: none;
  background: transparent;
  color: #888;
  font-size: 20px;
  line-height: 1;
  cursor: pointer;
  padding: 4px 8px;
  border-radius: 6px;
}
.remove:hover { background: rgba(0,0,0,0.04); color: #333; }

.empty {
  padding: 20px;
  text-align: center;
  color: #666;
  background: #fffbea;
  border: 1px dashed #ffe58f;
  border-radius: 8px;
}
</style>
