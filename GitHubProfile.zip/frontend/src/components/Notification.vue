<script setup>
import { ref, onMounted, onBeforeUnmount } from 'vue'

const props = defineProps({
  type: { type: String, default: 'info' }, 
  timeout: { type: Number, default: 0 },   
  dismissible: { type: Boolean, default: true }
})
const emit = defineEmits(['dismiss'])

const visible = ref(true)
let timeoutId = null

function close() {
  if (!visible.value) return
  visible.value = false
  emit('dismiss')
}

onMounted(() => {
  if (props.timeout > 0) {
    timeoutId = setTimeout(() => close(), props.timeout)
  }
})

onBeforeUnmount(() => {
  if (timeoutId) clearTimeout(timeoutId)
})
</script>

<template>
  <div v-if="visible" :class="['notification', `notification--${type}`]">
    <div class="content">
      <slot>
        Notification
      </slot>
    </div>

    <button v-if="dismissible" class="close" @click="close" aria-label="Dismiss">&times;</button>
  </div>
</template>

<style scoped>
.notification {
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap: 8px;
  padding: 10px 12px;
  border-radius: 8px;
  margin-bottom: 8px;
  box-shadow: 0 1px 2px rgba(0,0,0,0.04);
  font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
}
.notification .content { flex:1; }
.notification .close {
  background: transparent;
  border: none;
  font-size: 18px;
  cursor: pointer;
  color: inherit;
}

.notification--info { background: #e8f0ff; color: #0b63d6; }
.notification--success { background: #e6f4ea; color: #1b7a3b; }
.notification--warning { background: #fff7e6; color: #a86a00; }
.notification--error { background: #ffecec; color: #b00020; }
</style>
